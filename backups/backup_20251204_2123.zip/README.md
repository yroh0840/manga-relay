* 2025/11/18(火曜日)
* 漫画リレー
* ツール
* Flasc 
* python 3.12.7 
* tailwind

* DB(manga-relay) table(image)id,
リレー
